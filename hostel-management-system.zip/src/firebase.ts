import { UserProfile } from './types';

// Mock Auth for local development since Firebase was declined
const MOCK_USER: UserProfile = {
  uid: 'admin-123',
  email: 'admin@hostelhub.com',
  displayName: 'System Admin',
  role: 'admin',
  createdAt: Date.now()
};

export const auth = {
  currentUser: MOCK_USER
};

export const signInWithGoogle = async () => {
  return MOCK_USER;
};

export const logout = async () => {
  window.location.reload();
};

// API Helpers
export const api = {
  getDb: async () => {
    const res = await fetch('/api/db');
    return res.json();
  },
  create: async (collection: string, data: any) => {
    const res = await fetch(`/api/${collection}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },
  update: async (collection: string, id: string, data: any) => {
    const res = await fetch(`/api/${collection}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },
  delete: async (collection: string, id: string) => {
    await fetch(`/api/${collection}/${id}`, { method: 'DELETE' });
  }
};
