import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  HardHat, 
  Utensils, 
  Bed, 
  Library, 
  Gamepad2, 
  CheckSquare, 
  MessageSquare, 
  LogOut,
  Menu,
  X
} from 'lucide-react';
import { auth, logout } from '../firebase';
import { UserProfile } from '../types';
import { cn } from '../lib/utils';

interface LayoutProps {
  children: React.ReactNode;
  userProfile: UserProfile | null;
}

export default function Layout({ children, userProfile }: LayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(false);
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const navItems = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard, roles: ['admin', 'student', 'worker'] },
    { name: 'Students', path: '/students', icon: Users, roles: ['admin'] },
    { name: 'Workers', path: '/workers', icon: HardHat, roles: ['admin'] },
    { name: 'Rooms', path: '/rooms', icon: Bed, roles: ['admin', 'student'] },
    { name: 'Food Menu', path: '/food-menu', icon: Utensils, roles: ['admin', 'student'] },
    { name: 'Library', path: '/library', icon: Library, roles: ['admin', 'student'] },
    { name: 'Games', path: '/games', icon: Gamepad2, roles: ['admin', 'student'] },
    { name: 'Attendance', path: '/attendance', icon: CheckSquare, roles: ['admin', 'student'] },
    { name: 'Feedback', path: '/feedback', icon: MessageSquare, roles: ['admin', 'student'] },
  ];

  const filteredNavItems = navItems.filter(item => 
    userProfile && item.roles.includes(userProfile.role)
  );

  return (
    <div className="min-h-screen bg-neutral-50 flex">
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 left-0 w-64 bg-white border-r border-neutral-200 z-50 transition-transform lg:translate-x-0 lg:static lg:inset-0",
        isSidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="h-full flex flex-col">
          <div className="p-6 border-bottom border-neutral-100 flex items-center justify-between">
            <h1 className="text-xl font-bold text-neutral-900 flex items-center gap-2">
              <Bed className="w-6 h-6 text-blue-600" />
              HostelHub
            </h1>
            <button className="lg:hidden" onClick={() => setIsSidebarOpen(false)}>
              <X className="w-6 h-6" />
            </button>
          </div>

          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
            {filteredNavItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) => cn(
                  "flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors",
                  isActive 
                    ? "bg-blue-50 text-blue-700" 
                    : "text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900"
                )}
                onClick={() => setIsSidebarOpen(false)}
              >
                <item.icon className="w-5 h-5" />
                {item.name}
              </NavLink>
            ))}
          </nav>

          <div className="p-4 border-t border-neutral-100">
            <div className="flex items-center gap-3 px-4 py-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold overflow-hidden">
                {userProfile?.photoURL ? (
                  <img src={userProfile.photoURL} alt={userProfile.displayName} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                ) : (
                  userProfile?.displayName?.charAt(0) || 'U'
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-neutral-900 truncate">{userProfile?.displayName}</p>
                <p className="text-xs text-neutral-500 capitalize">{userProfile?.role}</p>
              </div>
            </div>
            <button 
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-red-600 hover:bg-red-50 transition-colors"
            >
              <LogOut className="w-5 h-5" />
              Logout
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="h-16 bg-white border-b border-neutral-200 flex items-center justify-between px-6 lg:hidden">
          <button onClick={() => setIsSidebarOpen(true)}>
            <Menu className="w-6 h-6 text-neutral-600" />
          </button>
          <h1 className="text-lg font-bold text-neutral-900">HostelHub</h1>
          <div className="w-6" /> {/* Spacer */}
        </header>

        <div className="flex-1 overflow-y-auto p-6 lg:p-10">
          {children}
        </div>
      </main>
    </div>
  );
}
