import React, { useEffect, useState } from 'react';
import { api } from '../firebase';
import { Game, UserProfile } from '../types';
import { 
  Gamepad2, 
  Plus, 
  Search, 
  Trash2, 
  Edit2,
  X,
  Trophy,
  Users,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import { cn } from '../lib/utils';

interface GamesProps {
  userProfile: UserProfile | null;
}

export default function Games({ userProfile }: GamesProps) {
  const [games, setGames] = useState<Game[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingGame, setEditingGame] = useState<Game | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    type: 'indoor' as 'indoor' | 'outdoor',
    status: 'available' as 'available' | 'in-use' | 'maintenance'
  });

  const isAdmin = userProfile?.role === 'admin';

  const fetchData = async () => {
    try {
      const db = await api.getDb();
      setGames(db.games);
    } catch (error) {
      console.error("Fetch games error:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const filteredGames = games.filter(g => 
    g.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    g.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingGame) {
        await api.update('games', editingGame.id, formData);
      } else {
        await api.create('games', formData);
      }
      setIsModalOpen(false);
      setEditingGame(null);
      setFormData({ name: '', type: 'indoor', status: 'available' });
      fetchData();
    } catch (error) {
      console.error("Error saving game:", error);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm("Are you sure you want to remove this game/equipment?")) {
      try {
        await api.delete('games', id);
        fetchData();
      } catch (error) {
        console.error("Error deleting game:", error);
      }
    }
  };

  const handleStatusChange = async (game: Game, newStatus: 'available' | 'in-use' | 'maintenance') => {
    try {
      await api.update('games', game.id, { status: newStatus });
      fetchData();
    } catch (error) {
      console.error("Error updating status:", error);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900 flex items-center gap-2">
            <Gamepad2 className="w-6 h-6 text-purple-600" />
            Games & Recreation
          </h1>
          <p className="text-neutral-500">Manage sports equipment and recreation room status.</p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
            <input 
              type="text" 
              placeholder="Search games..." 
              className="pl-10 pr-4 py-2 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 w-full md:w-64 shadow-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          {isAdmin && (
            <button 
              onClick={() => {
                setEditingGame(null);
                setFormData({ name: '', type: 'indoor', status: 'available' });
                setIsModalOpen(true);
              }}
              className="flex items-center gap-2 bg-purple-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-purple-700 transition-colors shadow-sm"
            >
              <Plus className="w-5 h-5" />
              Add Game
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {filteredGames.map((game) => (
          <div key={game.id} className="bg-white rounded-2xl border border-neutral-200 shadow-sm overflow-hidden group hover:border-purple-200 transition-colors">
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "w-12 h-12 rounded-xl flex items-center justify-center font-bold",
                    game.status === 'available' ? "bg-emerald-100 text-emerald-700" :
                    game.status === 'in-use' ? "bg-blue-100 text-blue-700" :
                    "bg-red-100 text-red-700"
                  )}>
                    <Trophy className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-neutral-900">{game.name}</h3>
                    <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">{game.type}</span>
                  </div>
                </div>
                
                {isAdmin && (
                  <div className="flex items-center gap-1">
                    <button onClick={() => {
                      setEditingGame(game);
                      setFormData({ name: game.name, type: game.type, status: game.status });
                      setIsModalOpen(true);
                    }} className="p-1.5 hover:bg-neutral-100 rounded-lg text-neutral-400 hover:text-neutral-900 transition-colors">
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button onClick={() => handleDelete(game.id)} className="p-1.5 hover:bg-red-50 rounded-lg text-neutral-400 hover:text-red-600 transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className={cn(
                    "inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider",
                    game.status === 'available' ? "bg-emerald-50 text-emerald-600" :
                    game.status === 'in-use' ? "bg-blue-50 text-blue-600" :
                    "bg-red-50 text-red-600"
                  )}>
                    {game.status}
                  </span>
                  {game.status === 'in-use' && (
                    <div className="flex items-center gap-1 text-[10px] text-blue-600 font-bold uppercase">
                      <Users className="w-3 h-3" />
                      In Use
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <button 
                    onClick={() => handleStatusChange(game, 'available')}
                    className={cn(
                      "p-1.5 rounded-lg text-[10px] font-bold uppercase transition-colors border",
                      game.status === 'available' ? "bg-emerald-600 text-white border-emerald-600" : "bg-white text-emerald-600 border-emerald-200 hover:bg-emerald-50"
                    )}
                  >
                    Free
                  </button>
                  <button 
                    onClick={() => handleStatusChange(game, 'in-use')}
                    className={cn(
                      "p-1.5 rounded-lg text-[10px] font-bold uppercase transition-colors border",
                      game.status === 'in-use' ? "bg-blue-600 text-white border-blue-600" : "bg-white text-blue-600 border-blue-200 hover:bg-blue-50"
                    )}
                  >
                    Use
                  </button>
                  <button 
                    onClick={() => handleStatusChange(game, 'maintenance')}
                    className={cn(
                      "p-1.5 rounded-lg text-[10px] font-bold uppercase transition-colors border",
                      game.status === 'maintenance' ? "bg-red-600 text-white border-red-600" : "bg-white text-red-600 border-red-200 hover:bg-red-50"
                    )}
                  >
                    Fix
                  </button>
                </div>
              </div>
            </div>
            
            <div className="px-6 py-4 bg-neutral-50 border-t border-neutral-100 flex items-center justify-between">
              <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">ID: {game.id.slice(-4)}</span>
              {game.status === 'available' ? (
                <div className="flex items-center gap-1 text-[10px] font-bold text-emerald-600 uppercase">
                  <CheckCircle2 className="w-3 h-3" />
                  Available
                </div>
              ) : game.status === 'maintenance' ? (
                <div className="flex items-center gap-1 text-[10px] font-bold text-red-600 uppercase">
                  <AlertCircle className="w-3 h-3" />
                  Repair
                </div>
              ) : null}
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-6">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-xl overflow-hidden">
            <div className="p-6 border-b border-neutral-100 flex items-center justify-between">
              <h2 className="text-lg font-bold text-neutral-900">{editingGame ? 'Edit Game' : 'Add New Game'}</h2>
              <button onClick={() => setIsModalOpen(false)}>
                <X className="w-6 h-6 text-neutral-400" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-neutral-400 uppercase mb-1">Game Name</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g. Table Tennis, Chess, Football"
                  className="w-full px-4 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-neutral-400 uppercase mb-1">Type</label>
                <select 
                  className="w-full px-4 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                >
                  <option value="indoor">Indoor</option>
                  <option value="outdoor">Outdoor</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-neutral-400 uppercase mb-1">Status</label>
                <select 
                  className="w-full px-4 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                >
                  <option value="available">Available</option>
                  <option value="in-use">In Use</option>
                  <option value="maintenance">Maintenance</option>
                </select>
              </div>
              <div className="pt-4">
                <button 
                  type="submit"
                  className="w-full bg-purple-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-purple-700 transition-colors shadow-sm"
                >
                  {editingGame ? 'Save Changes' : 'Add Game'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
