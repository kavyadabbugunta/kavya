import React, { useEffect, useState } from 'react';
import { api } from '../firebase';
import { FoodMenuItem, UserProfile } from '../types';
import { 
  Utensils, 
  Plus, 
  Trash2, 
  Edit2,
  X,
  Clock,
  Calendar
} from 'lucide-react';
import { cn } from '../lib/utils';

interface FoodMenuProps {
  userProfile: UserProfile | null;
}

export default function FoodMenu({ userProfile }: FoodMenuProps) {
  const [menu, setMenu] = useState<FoodMenuItem[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<FoodMenuItem | null>(null);
  const [formData, setFormData] = useState({
    day: 'Monday' as any,
    mealType: 'breakfast' as any,
    items: '',
    time: ''
  });

  const isAdmin = userProfile?.role === 'admin';
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const mealTypes = ['breakfast', 'lunch', 'dinner'];

  const fetchData = async () => {
    try {
      const db = await api.getDb();
      setMenu(db.foodMenu);
    } catch (error) {
      console.error("Fetch menu error:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        ...formData,
        items: formData.items.split(',').map(i => i.trim())
      };
      if (editingItem) {
        await api.update('foodMenu', editingItem.id, payload);
      } else {
        await api.create('foodMenu', payload);
      }
      setIsModalOpen(false);
      setEditingItem(null);
      setFormData({ day: 'Monday', mealType: 'breakfast', items: '', time: '' });
      fetchData();
    } catch (error) {
      console.error("Error saving menu item:", error);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm("Are you sure you want to remove this menu item?")) {
      try {
        await api.delete('foodMenu', id);
        fetchData();
      } catch (error) {
        console.error("Error deleting menu item:", error);
      }
    }
  };

  const handleEdit = (item: FoodMenuItem) => {
    setEditingItem(item);
    setFormData({
      day: item.day,
      mealType: item.mealType,
      items: item.items.join(', '),
      time: item.time
    });
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900 flex items-center gap-2">
            <Utensils className="w-6 h-6 text-rose-600" />
            Weekly Food Menu
          </h1>
          <p className="text-neutral-500">View and manage the hostel dining schedule.</p>
        </div>

        {isAdmin && (
          <button 
            onClick={() => {
              setEditingItem(null);
              setFormData({ day: 'Monday', mealType: 'breakfast', items: '', time: '' });
              setIsModalOpen(true);
            }}
            className="flex items-center gap-2 bg-rose-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-rose-700 transition-colors shadow-sm"
          >
            <Plus className="w-5 h-5" />
            Add Menu Item
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-7 gap-6 overflow-x-auto pb-4">
        {days.map((day) => (
          <div key={day} className="min-w-[280px] space-y-4">
            <div className="flex items-center gap-2 px-2">
              <Calendar className="w-4 h-4 text-rose-600" />
              <h3 className="text-sm font-bold text-neutral-900">{day}</h3>
            </div>
            
            <div className="space-y-3">
              {mealTypes.map((type) => {
                const item = menu.find(m => m.day === day && m.mealType === type);
                return (
                  <div key={type} className="bg-white rounded-2xl border border-neutral-200 p-4 shadow-sm group hover:border-rose-200 transition-colors">
                    <div className="flex items-center justify-between mb-2">
                      <span className={cn(
                        "text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded",
                        type === 'breakfast' ? "bg-amber-50 text-amber-600" :
                        type === 'lunch' ? "bg-emerald-50 text-emerald-600" :
                        "bg-indigo-50 text-indigo-600"
                      )}>
                        {type}
                      </span>
                      {isAdmin && item && (
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button onClick={() => handleEdit(item)} className="p-1 hover:bg-neutral-100 rounded text-neutral-400 hover:text-neutral-900">
                            <Edit2 className="w-3 h-3" />
                          </button>
                          <button onClick={() => handleDelete(item.id)} className="p-1 hover:bg-red-50 rounded text-neutral-400 hover:text-red-600">
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>

                    {item ? (
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-[10px] text-neutral-400 font-bold uppercase">
                          <Clock className="w-3 h-3" />
                          {item.time}
                        </div>
                        <ul className="space-y-1">
                          {item.items.map((food, i) => (
                            <li key={i} className="text-xs text-neutral-600 flex items-center gap-2">
                              <div className="w-1 h-1 rounded-full bg-rose-400" />
                              {food}
                            </li>
                          ))}
                        </ul>
                      </div>
                    ) : (
                      <div className="py-4 text-center">
                        <p className="text-[10px] text-neutral-400 italic">No menu set</p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-6">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-xl overflow-hidden">
            <div className="p-6 border-b border-neutral-100 flex items-center justify-between">
              <h2 className="text-lg font-bold text-neutral-900">{editingItem ? 'Edit Menu' : 'Add Menu Item'}</h2>
              <button onClick={() => setIsModalOpen(false)}>
                <X className="w-6 h-6 text-neutral-400" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-400 uppercase mb-1">Day</label>
                  <select 
                    className="w-full px-4 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-500"
                    value={formData.day}
                    onChange={(e) => setFormData({ ...formData, day: e.target.value as any })}
                  >
                    {days.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-neutral-400 uppercase mb-1">Meal Type</label>
                  <select 
                    className="w-full px-4 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-500"
                    value={formData.mealType}
                    onChange={(e) => setFormData({ ...formData, mealType: e.target.value as any })}
                  >
                    {mealTypes.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-neutral-400 uppercase mb-1">Time</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g. 8:00 AM - 9:30 AM"
                  className="w-full px-4 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-500"
                  value={formData.time}
                  onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-neutral-400 uppercase mb-1">Food Items (comma separated)</label>
                <textarea 
                  required
                  placeholder="e.g. Eggs, Toast, Coffee"
                  className="w-full px-4 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-500 h-24 resize-none"
                  value={formData.items}
                  onChange={(e) => setFormData({ ...formData, items: e.target.value })}
                />
              </div>
              <div className="pt-4">
                <button 
                  type="submit"
                  className="w-full bg-rose-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-rose-700 transition-colors shadow-sm"
                >
                  {editingItem ? 'Save Changes' : 'Add to Menu'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
