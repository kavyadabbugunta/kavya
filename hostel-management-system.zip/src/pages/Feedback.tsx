import React, { useEffect, useState } from 'react';
import { api } from '../firebase';
import { Feedback, UserProfile } from '../types';
import { 
  MessageSquare, 
  Send, 
  Trash2, 
  Star,
  User,
  Clock,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { cn } from '../lib/utils';

interface FeedbackProps {
  userProfile: UserProfile | null;
}

export default function FeedbackPage({ userProfile }: FeedbackProps) {
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [message, setMessage] = useState('');
  const [rating, setRating] = useState(5);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const isAdmin = userProfile?.role === 'admin';

  const fetchData = async () => {
    try {
      const db = await api.getDb();
      setFeedbacks(db.feedback.sort((a: any, b: any) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
    } catch (error) {
      console.error("Fetch feedback error:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    setIsSubmitting(true);
    try {
      await api.create('feedback', {
        studentId: userProfile?.uid,
        studentName: userProfile?.displayName,
        message,
        rating,
        timestamp: new Date().toISOString()
      });
      setMessage('');
      setRating(5);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
      fetchData();
    } catch (error) {
      console.error("Error submitting feedback:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm("Are you sure you want to delete this feedback?")) {
      try {
        await api.delete('feedback', id);
        fetchData();
      } catch (error) {
        console.error("Error deleting feedback:", error);
      }
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-neutral-900 flex items-center justify-center gap-3">
          <MessageSquare className="w-8 h-8 text-blue-600" />
          Feedback & Suggestions
        </h1>
        <p className="text-neutral-500">Help us improve your hostel experience.</p>
      </div>

      {!isAdmin && (
        <div className="bg-white rounded-2xl border border-neutral-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-neutral-100 bg-neutral-50/50">
            <h2 className="text-sm font-bold text-neutral-900 uppercase tracking-wider">Submit Feedback</h2>
          </div>
          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            <div className="space-y-3">
              <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider">How would you rate your experience?</label>
              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className={cn(
                      "p-1 transition-all hover:scale-110",
                      rating >= star ? "text-amber-400" : "text-neutral-200"
                    )}
                  >
                    <Star className="w-8 h-8 fill-current" />
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider">Your Message</label>
              <textarea
                required
                placeholder="Share your thoughts, complaints, or suggestions..."
                className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 h-32 resize-none"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {success && (
                  <div className="flex items-center gap-2 text-emerald-600 text-xs font-bold animate-in fade-in slide-in-from-left-2">
                    <CheckCircle2 className="w-4 h-4" />
                    Feedback submitted successfully!
                  </div>
                )}
              </div>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-sm disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                {isSubmitting ? 'Submitting...' : 'Submit Feedback'}
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="space-y-6">
        <div className="flex items-center justify-between px-2">
          <h2 className="text-sm font-bold text-neutral-900 uppercase tracking-wider">
            {isAdmin ? 'All Feedback' : 'Recent Feedback'}
          </h2>
          <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">{feedbacks.length} Total</span>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {feedbacks.map((fb) => (
            <div key={fb.id} className="bg-white rounded-2xl border border-neutral-200 shadow-sm p-6 group hover:border-blue-200 transition-colors">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold">
                    <User className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-neutral-900">{fb.studentName}</h3>
                    <div className="flex items-center gap-1 mt-0.5">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star 
                          key={star} 
                          className={cn(
                            "w-3 h-3 fill-current",
                            fb.rating >= star ? "text-amber-400" : "text-neutral-200"
                          )} 
                        />
                      ))}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 text-[10px] text-neutral-400 font-bold uppercase">
                    <Clock className="w-3 h-3" />
                    {new Date(fb.timestamp).toLocaleDateString()}
                  </div>
                  {isAdmin && (
                    <button 
                      onClick={() => handleDelete(fb.id)}
                      className="p-1.5 hover:bg-red-50 rounded-lg text-neutral-400 hover:text-red-600 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              <p className="text-sm text-neutral-600 leading-relaxed pl-13">
                {fb.message}
              </p>
              
              {isAdmin && (
                <div className="mt-4 pl-13 flex items-center gap-4">
                  <button className="text-[10px] font-bold text-blue-600 hover:text-blue-700 uppercase tracking-wider">Mark as Read</button>
                  <button className="text-[10px] font-bold text-neutral-400 hover:text-neutral-600 uppercase tracking-wider">Reply</button>
                </div>
              )}
            </div>
          ))}

          {feedbacks.length === 0 && (
            <div className="text-center py-12 bg-neutral-50 rounded-2xl border border-dashed border-neutral-200">
              <AlertCircle className="w-8 h-8 text-neutral-300 mx-auto mb-3" />
              <p className="text-sm text-neutral-500 font-medium">No feedback received yet.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
