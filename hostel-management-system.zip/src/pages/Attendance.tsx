import React, { useEffect, useState } from 'react';
import { api } from '../firebase';
import { Attendance, UserProfile } from '../types';
import { 
  CalendarCheck, 
  Search, 
  CheckCircle2, 
  XCircle, 
  Clock,
  User,
  Filter,
  Download
} from 'lucide-react';
import { cn } from '../lib/utils';

interface AttendanceProps {
  userProfile: UserProfile | null;
}

export default function AttendancePage({ userProfile }: AttendanceProps) {
  const [students, setStudents] = useState<UserProfile[]>([]);
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(true);

  const isAdmin = userProfile?.role === 'admin';

  const fetchData = async () => {
    try {
      const db = await api.getDb();
      setStudents(db.users.filter((u: any) => u.role === 'student'));
      setAttendance(db.attendance.filter((a: any) => a.date === selectedDate));
    } catch (error) {
      console.error("Fetch attendance error:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [selectedDate]);

  const handleMarkAttendance = async (studentId: string, status: 'present' | 'absent') => {
    try {
      const existing = attendance.find(a => a.studentId === studentId);
      if (existing) {
        await api.update('attendance', existing.id, { status, timestamp: new Date().toISOString() });
      } else {
        await api.create('attendance', {
          studentId,
          date: selectedDate,
          status,
          timestamp: new Date().toISOString()
        });
      }
      fetchData();
    } catch (error) {
      console.error("Error marking attendance:", error);
    }
  };

  const filteredStudents = students.filter(s => 
    s.displayName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const stats = {
    total: students.length,
    present: attendance.filter(a => a.status === 'present').length,
    absent: attendance.filter(a => a.status === 'absent').length,
    pending: students.length - attendance.length
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900 flex items-center gap-2">
            <CalendarCheck className="w-6 h-6 text-blue-600" />
            Daily Attendance
          </h1>
          <p className="text-neutral-500">Track and manage student daily presence.</p>
        </div>

        <div className="flex items-center gap-3">
          <input 
            type="date" 
            className="px-4 py-2 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
          />
          <button className="p-2 bg-white border border-neutral-200 rounded-xl hover:bg-neutral-50 transition-colors shadow-sm">
            <Download className="w-5 h-5 text-neutral-600" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Students', value: stats.total, color: 'bg-neutral-100 text-neutral-600' },
          { label: 'Present', value: stats.present, color: 'bg-emerald-100 text-emerald-600' },
          { label: 'Absent', value: stats.absent, color: 'bg-red-100 text-red-600' },
          { label: 'Pending', value: stats.pending, color: 'bg-amber-100 text-amber-600' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-sm">
            <p className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider mb-1">{stat.label}</p>
            <p className={cn("text-xl font-bold", stat.color.split(' ')[1])}>{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-neutral-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-neutral-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
            <input 
              type="text" 
              placeholder="Search students..." 
              className="pl-10 pr-4 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-full"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 px-3 py-2 text-xs font-bold text-neutral-600 hover:bg-neutral-50 rounded-lg transition-colors border border-neutral-200">
              <Filter className="w-4 h-4" />
              Filter
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-neutral-50 border-b border-neutral-100">
                <th className="px-6 py-4 text-[10px] font-bold text-neutral-400 uppercase tracking-wider">Student</th>
                <th className="px-6 py-4 text-[10px] font-bold text-neutral-400 uppercase tracking-wider">Room</th>
                <th className="px-6 py-4 text-[10px] font-bold text-neutral-400 uppercase tracking-wider">Status</th>
                <th className="px-6 py-4 text-[10px] font-bold text-neutral-400 uppercase tracking-wider">Last Updated</th>
                <th className="px-6 py-4 text-[10px] font-bold text-neutral-400 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {filteredStudents.map((student) => {
                const record = attendance.find(a => a.studentId === student.uid);
                return (
                  <tr key={student.uid} className="hover:bg-neutral-50/50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 text-xs font-bold">
                          {student.displayName.charAt(0)}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-neutral-900">{student.displayName}</p>
                          <p className="text-[10px] text-neutral-400">{student.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-xs font-medium text-neutral-600">302B</span>
                    </td>
                    <td className="px-6 py-4">
                      {record ? (
                        <span className={cn(
                          "inline-flex items-center gap-1.5 px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider",
                          record.status === 'present' ? "bg-emerald-50 text-emerald-600" : "bg-red-50 text-red-600"
                        )}>
                          {record.status === 'present' ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                          {record.status}
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-amber-50 text-amber-600">
                          Pending
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-xs text-neutral-400">
                        <Clock className="w-3 h-3" />
                        {record ? new Date(record.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--:--'}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      {isAdmin && (
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => handleMarkAttendance(student.uid, 'present')}
                            className={cn(
                              "p-2 rounded-xl transition-all",
                              record?.status === 'present' ? "bg-emerald-600 text-white" : "bg-neutral-100 text-neutral-400 hover:bg-emerald-50 hover:text-emerald-600"
                            )}
                          >
                            <CheckCircle2 className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleMarkAttendance(student.uid, 'absent')}
                            className={cn(
                              "p-2 rounded-xl transition-all",
                              record?.status === 'absent' ? "bg-red-600 text-white" : "bg-neutral-100 text-neutral-400 hover:bg-red-50 hover:text-red-600"
                            )}
                          >
                            <XCircle className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
