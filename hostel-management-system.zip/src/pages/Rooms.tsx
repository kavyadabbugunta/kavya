import React, { useEffect, useState } from 'react';
import { api } from '../firebase';
import { Room, UserProfile } from '../types';
import { 
  Bed, 
  Plus, 
  Search, 
  Trash2, 
  Edit2,
  X,
  Users,
  AlertCircle
} from 'lucide-react';
import { cn } from '../lib/utils';

interface RoomsProps {
  userProfile: UserProfile | null;
}

export default function Rooms({ userProfile }: RoomsProps) {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRoom, setEditingRoom] = useState<Room | null>(null);
  const [formData, setFormData] = useState({
    roomNumber: '',
    capacity: 2,
    status: 'available' as 'available' | 'full' | 'maintenance'
  });

  const isAdmin = userProfile?.role === 'admin';

  const fetchData = async () => {
    try {
      const db = await api.getDb();
      setRooms(db.rooms);
    } catch (error) {
      console.error("Fetch rooms error:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const filteredRooms = rooms.filter(r => 
    r.roomNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingRoom) {
        await api.update('rooms', editingRoom.id, formData);
      } else {
        await api.create('rooms', { ...formData, occupants: [] });
      }
      setIsModalOpen(false);
      setEditingRoom(null);
      setFormData({ roomNumber: '', capacity: 2, status: 'available' });
      fetchData();
    } catch (error) {
      console.error("Error saving room:", error);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm("Are you sure you want to remove this room?")) {
      try {
        await api.delete('rooms', id);
        fetchData();
      } catch (error) {
        console.error("Error deleting room:", error);
      }
    }
  };

  const handleEdit = (room: Room) => {
    setEditingRoom(room);
    setFormData({
      roomNumber: room.roomNumber,
      capacity: room.capacity,
      status: room.status
    });
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900 flex items-center gap-2">
            <Bed className="w-6 h-6 text-emerald-600" />
            Room Management
          </h1>
          <p className="text-neutral-500">View and manage hostel room allocations.</p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
            <input 
              type="text" 
              placeholder="Search rooms..." 
              className="pl-10 pr-4 py-2 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 w-full md:w-64 shadow-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          {isAdmin && (
            <button 
              onClick={() => {
                setEditingRoom(null);
                setFormData({ roomNumber: '', capacity: 2, status: 'available' });
                setIsModalOpen(true);
              }}
              className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-emerald-700 transition-colors shadow-sm"
            >
              <Plus className="w-5 h-5" />
              Add Room
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {filteredRooms.map((room) => (
          <div key={room.id} className="bg-white rounded-2xl border border-neutral-200 shadow-sm overflow-hidden group hover:border-emerald-200 transition-colors">
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "w-12 h-12 rounded-xl flex items-center justify-center font-bold",
                    room.status === 'available' ? "bg-emerald-100 text-emerald-700" :
                    room.status === 'full' ? "bg-blue-100 text-blue-700" :
                    "bg-red-100 text-red-700"
                  )}>
                    {room.roomNumber}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-neutral-900">Room {room.roomNumber}</h3>
                    <span className={cn(
                      "inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider",
                      room.status === 'available' ? "bg-emerald-50 text-emerald-600" :
                      room.status === 'full' ? "bg-blue-50 text-blue-600" :
                      "bg-red-50 text-red-600"
                    )}>
                      {room.status}
                    </span>
                  </div>
                </div>
                
                {isAdmin && (
                  <div className="flex items-center gap-1">
                    <button 
                      onClick={() => handleEdit(room)}
                      className="p-1.5 hover:bg-neutral-100 rounded-lg text-neutral-400 hover:text-neutral-900 transition-colors"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => handleDelete(room.id)}
                      className="p-1.5 hover:bg-red-50 rounded-lg text-neutral-400 hover:text-red-600 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs text-neutral-600">
                    <Users className="w-4 h-4 text-neutral-400" />
                    Occupancy
                  </div>
                  <span className="text-xs font-bold text-neutral-900">{room.occupants.length} / {room.capacity}</span>
                </div>
                
                <div className="w-full bg-neutral-100 h-2 rounded-full overflow-hidden">
                  <div 
                    className={cn(
                      "h-full transition-all duration-500",
                      room.occupants.length >= room.capacity ? "bg-blue-600" : "bg-emerald-500"
                    )}
                    style={{ width: `${(room.occupants.length / room.capacity) * 100}%` }}
                  />
                </div>

                {room.status === 'maintenance' && (
                  <div className="flex items-center gap-2 p-2 bg-red-50 rounded-lg text-red-700 text-[10px] font-medium">
                    <AlertCircle className="w-3 h-3" />
                    Room under maintenance
                  </div>
                )}
              </div>
            </div>
            
            <div className="px-6 py-4 bg-neutral-50 border-t border-neutral-100 flex items-center justify-between">
              <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">Floor: {room.roomNumber.charAt(0)}</span>
              <button className="text-xs font-bold text-emerald-600 hover:text-emerald-700">View Details</button>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-6">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-xl overflow-hidden">
            <div className="p-6 border-b border-neutral-100 flex items-center justify-between">
              <h2 className="text-lg font-bold text-neutral-900">{editingRoom ? 'Edit Room' : 'Add New Room'}</h2>
              <button onClick={() => setIsModalOpen(false)}>
                <X className="w-6 h-6 text-neutral-400" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-neutral-400 uppercase mb-1">Room Number</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g. 101, 204B"
                  className="w-full px-4 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  value={formData.roomNumber}
                  onChange={(e) => setFormData({ ...formData, roomNumber: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-neutral-400 uppercase mb-1">Capacity</label>
                <input 
                  type="number" 
                  required
                  min="1"
                  max="10"
                  className="w-full px-4 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  value={formData.capacity}
                  onChange={(e) => setFormData({ ...formData, capacity: parseInt(e.target.value) })}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-neutral-400 uppercase mb-1">Status</label>
                <select 
                  className="w-full px-4 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                >
                  <option value="available">Available</option>
                  <option value="full">Full</option>
                  <option value="maintenance">Maintenance</option>
                </select>
              </div>
              <div className="pt-4">
                <button 
                  type="submit"
                  className="w-full bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors shadow-sm"
                >
                  {editingRoom ? 'Save Changes' : 'Add Room'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
