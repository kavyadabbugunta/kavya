import React, { useEffect, useState } from 'react';
import { api } from '../firebase';
import { UserProfile, Room, Attendance, Feedback } from '../types';
import { 
  Users, 
  Bed, 
  CheckSquare, 
  MessageSquare,
  TrendingUp,
  Clock,
  Calendar
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '../lib/utils';

interface DashboardProps {
  userProfile: UserProfile | null;
}

export default function Dashboard({ userProfile }: DashboardProps) {
  const [stats, setStats] = useState({
    totalStudents: 0,
    totalRooms: 0,
    availableRooms: 0,
    todayAttendance: 0,
  });
  const [recentFeedback, setRecentFeedback] = useState<Feedback[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const db = await api.getDb();
        const students = db.users.filter((u: any) => u.role === 'student');
        const rooms = db.rooms as Room[];
        const available = rooms.filter(r => r.status === 'available').length;
        const today = format(new Date(), 'yyyy-MM-dd');
        const todayAtt = db.attendance.filter((a: any) => a.date === today).length;
        
        setStats({
          totalStudents: students.length,
          totalRooms: rooms.length,
          availableRooms: available,
          todayAttendance: todayAtt
        });
        
        setRecentFeedback(db.feedback.slice(-5).reverse());
      } catch (error) {
        console.error("Dashboard fetch error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 5000); // Poll every 5s
    return () => clearInterval(interval);
  }, [userProfile]);

  const cards = [
    { name: 'Total Students', value: stats.totalStudents, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
    { name: 'Total Rooms', value: stats.totalRooms, icon: Bed, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { name: 'Available Rooms', value: stats.availableRooms, icon: TrendingUp, color: 'text-purple-600', bg: 'bg-purple-50' },
    { name: 'Today Attendance', value: stats.todayAttendance, icon: CheckSquare, color: 'text-orange-600', bg: 'bg-orange-50' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-neutral-900">Welcome back, {userProfile?.displayName}!</h1>
        <p className="text-neutral-500">Here's what's happening at the hostel today.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card) => (
          <div key={card.name} className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className={cn("p-3 rounded-xl", card.bg)}>
                <card.icon className={cn("w-6 h-6", card.color)} />
              </div>
              <span className="text-xs font-medium text-neutral-400 uppercase tracking-wider">{card.name}</span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold text-neutral-900">{card.value}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Feedback */}
        <div className="bg-white rounded-2xl border border-neutral-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-neutral-100 flex items-center justify-between">
            <h2 className="text-lg font-bold text-neutral-900 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-blue-600" />
              Recent Feedback
            </h2>
          </div>
          <div className="divide-y divide-neutral-100">
            {recentFeedback.length > 0 ? (
              recentFeedback.map((item) => (
                <div key={item.id} className="p-6 hover:bg-neutral-50 transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-bold text-neutral-900">{item.studentName}</span>
                    <span className="text-xs text-neutral-400 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {format(item.createdAt, 'MMM d, h:mm a')}
                    </span>
                  </div>
                  <p className="text-sm text-neutral-600 line-clamp-2">{item.message}</p>
                  <div className="mt-2">
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-neutral-100 text-neutral-600 capitalize">
                      {item.category}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-10 text-center text-neutral-500">No feedback yet.</div>
            )}
          </div>
        </div>

        {/* Quick Schedule */}
        <div className="bg-white rounded-2xl border border-neutral-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-neutral-100 flex items-center justify-between">
            <h2 className="text-lg font-bold text-neutral-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-emerald-600" />
              Today's Schedule
            </h2>
          </div>
          <div className="p-6 space-y-6">
            <div className="flex gap-4">
              <div className="w-12 text-center">
                <span className="block text-xs font-bold text-neutral-400 uppercase">8:00</span>
                <span className="block text-xs font-medium text-neutral-400 uppercase">AM</span>
              </div>
              <div className="flex-1 p-4 bg-blue-50 rounded-xl border-l-4 border-blue-600">
                <h3 className="text-sm font-bold text-blue-900">Breakfast</h3>
                <p className="text-xs text-blue-700">Pancakes & Coffee</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-12 text-center">
                <span className="block text-xs font-bold text-neutral-400 uppercase">1:00</span>
                <span className="block text-xs font-medium text-neutral-400 uppercase">PM</span>
              </div>
              <div className="flex-1 p-4 bg-emerald-50 rounded-xl border-l-4 border-emerald-600">
                <h3 className="text-sm font-bold text-emerald-900">Lunch</h3>
                <p className="text-xs text-emerald-700">Rice, Dal & Veggies</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-12 text-center">
                <span className="block text-xs font-bold text-neutral-400 uppercase">5:00</span>
                <span className="block text-xs font-medium text-neutral-400 uppercase">PM</span>
              </div>
              <div className="flex-1 p-4 bg-purple-50 rounded-xl border-l-4 border-purple-600">
                <h3 className="text-sm font-bold text-purple-900">Indoor Games</h3>
                <p className="text-xs text-purple-700">Table Tennis Tournament</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
