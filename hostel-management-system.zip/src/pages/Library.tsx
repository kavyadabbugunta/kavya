import React, { useEffect, useState } from 'react';
import { api } from '../firebase';
import { LibraryBook, UserProfile } from '../types';
import { 
  BookOpen, 
  Plus, 
  Search, 
  Trash2, 
  Edit2,
  X,
  Book,
  User,
  Clock,
  CheckCircle2,
  ArrowRightLeft
} from 'lucide-react';
import { cn } from '../lib/utils';

interface LibraryProps {
  userProfile: UserProfile | null;
}

export default function Library({ userProfile }: LibraryProps) {
  const [books, setBooks] = useState<LibraryBook[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBook, setEditingBook] = useState<LibraryBook | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    author: '',
    category: '',
    status: 'available' as 'available' | 'borrowed'
  });

  const isAdmin = userProfile?.role === 'admin';

  const fetchData = async () => {
    try {
      const db = await api.getDb();
      setBooks(db.library);
    } catch (error) {
      console.error("Fetch books error:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const filteredBooks = books.filter(b => 
    b.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    b.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
    b.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingBook) {
        await api.update('library', editingBook.id, formData);
      } else {
        await api.create('library', formData);
      }
      setIsModalOpen(false);
      setEditingBook(null);
      setFormData({ title: '', author: '', category: '', status: 'available' });
      fetchData();
    } catch (error) {
      console.error("Error saving book:", error);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm("Are you sure you want to remove this book?")) {
      try {
        await api.delete('library', id);
        fetchData();
      } catch (error) {
        console.error("Error deleting book:", error);
      }
    }
  };

  const handleBorrowReturn = async (book: LibraryBook) => {
    try {
      const newStatus = book.status === 'available' ? 'borrowed' : 'available';
      const borrowerId = newStatus === 'borrowed' ? userProfile?.uid : undefined;
      const borrowerName = newStatus === 'borrowed' ? userProfile?.displayName : undefined;
      const dueDate = newStatus === 'borrowed' ? new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString() : undefined;

      await api.update('library', book.id, {
        status: newStatus,
        borrowerId,
        borrowerName,
        dueDate
      });
      fetchData();
    } catch (error) {
      console.error("Error updating book status:", error);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900 flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-indigo-600" />
            Hostel Library
          </h1>
          <p className="text-neutral-500">Browse and borrow books from the common library.</p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
            <input 
              type="text" 
              placeholder="Search books..." 
              className="pl-10 pr-4 py-2 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 w-full md:w-64 shadow-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          {isAdmin && (
            <button 
              onClick={() => {
                setEditingBook(null);
                setFormData({ title: '', author: '', category: '', status: 'available' });
                setIsModalOpen(true);
              }}
              className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-indigo-700 transition-colors shadow-sm"
            >
              <Plus className="w-5 h-5" />
              Add Book
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredBooks.map((book) => (
          <div key={book.id} className="bg-white rounded-2xl border border-neutral-200 shadow-sm overflow-hidden group hover:border-indigo-200 transition-colors">
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "w-12 h-12 rounded-xl flex items-center justify-center font-bold",
                    book.status === 'available' ? "bg-indigo-100 text-indigo-700" : "bg-amber-100 text-amber-700"
                  )}>
                    <Book className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-neutral-900 line-clamp-1">{book.title}</h3>
                    <span className="text-xs text-neutral-500">{book.author}</span>
                  </div>
                </div>
                
                {isAdmin && (
                  <div className="flex items-center gap-1">
                    <button onClick={() => {
                      setEditingBook(book);
                      setFormData({ title: book.title, author: book.author, category: book.category, status: book.status });
                      setIsModalOpen(true);
                    }} className="p-1.5 hover:bg-neutral-100 rounded-lg text-neutral-400 hover:text-neutral-900 transition-colors">
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button onClick={() => handleDelete(book.id)} className="p-1.5 hover:bg-red-50 rounded-lg text-neutral-400 hover:text-red-600 transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">{book.category}</span>
                  <span className={cn(
                    "inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider",
                    book.status === 'available' ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"
                  )}>
                    {book.status}
                  </span>
                </div>

                {book.status === 'borrowed' && (
                  <div className="p-3 bg-amber-50 rounded-xl space-y-2">
                    <div className="flex items-center gap-2 text-[10px] text-amber-700 font-bold uppercase">
                      <User className="w-3 h-3" />
                      Borrowed by: {book.borrowerName}
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-amber-700 font-bold uppercase">
                      <Clock className="w-3 h-3" />
                      Due: {new Date(book.dueDate!).toLocaleDateString()}
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            <div className="px-6 py-4 bg-neutral-50 border-t border-neutral-100 flex items-center justify-between">
              <button 
                onClick={() => handleBorrowReturn(book)}
                disabled={book.status === 'borrowed' && book.borrowerId !== userProfile?.uid && !isAdmin}
                className={cn(
                  "flex items-center gap-2 text-xs font-bold transition-colors",
                  book.status === 'available' ? "text-indigo-600 hover:text-indigo-700" : "text-amber-600 hover:text-amber-700",
                  book.status === 'borrowed' && book.borrowerId !== userProfile?.uid && !isAdmin && "opacity-50 cursor-not-allowed"
                )}
              >
                <ArrowRightLeft className="w-4 h-4" />
                {book.status === 'available' ? 'Borrow Book' : 'Return Book'}
              </button>
              {book.status === 'available' && (
                <div className="flex items-center gap-1 text-[10px] font-bold text-emerald-600 uppercase">
                  <CheckCircle2 className="w-3 h-3" />
                  Ready
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-6">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-xl overflow-hidden">
            <div className="p-6 border-b border-neutral-100 flex items-center justify-between">
              <h2 className="text-lg font-bold text-neutral-900">{editingBook ? 'Edit Book' : 'Add New Book'}</h2>
              <button onClick={() => setIsModalOpen(false)}>
                <X className="w-6 h-6 text-neutral-400" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-neutral-400 uppercase mb-1">Book Title</label>
                <input 
                  type="text" 
                  required
                  className="w-full px-4 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-neutral-400 uppercase mb-1">Author</label>
                <input 
                  type="text" 
                  required
                  className="w-full px-4 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  value={formData.author}
                  onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-neutral-400 uppercase mb-1">Category</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g. Fiction, Science, History"
                  className="w-full px-4 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                />
              </div>
              <div className="pt-4">
                <button 
                  type="submit"
                  className="w-full bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-sm"
                >
                  {editingBook ? 'Save Changes' : 'Add Book'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
