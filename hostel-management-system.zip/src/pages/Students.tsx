import React, { useEffect, useState } from 'react';
import { api } from '../firebase';
import { UserProfile } from '../types';
import { 
  Users, 
  Search, 
  MoreVertical, 
  Trash2, 
  Shield,
  GraduationCap,
  Phone,
  Mail,
  HardHat
} from 'lucide-react';

interface StudentsProps {
  userProfile: UserProfile | null;
}

export default function Students({ userProfile }: StudentsProps) {
  const [students, setStudents] = useState<UserProfile[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const db = await api.getDb();
      setStudents(db.users.filter((u: any) => u.role === 'student'));
    } catch (error) {
      console.error("Fetch students error:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const filteredStudents = students.filter(s => 
    s.displayName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleRoleChange = async (uid: string, newRole: 'admin' | 'student' | 'worker') => {
    try {
      await api.update('users', uid, { role: newRole });
      fetchData();
    } catch (error) {
      console.error("Error updating role:", error);
    }
  };

  const handleDelete = async (uid: string) => {
    if (window.confirm("Are you sure you want to remove this user?")) {
      try {
        await api.delete('users', uid);
        fetchData();
      } catch (error) {
        console.error("Error deleting user:", error);
      }
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900 flex items-center gap-2">
            <Users className="w-6 h-6 text-blue-600" />
            Student Management
          </h1>
          <p className="text-neutral-500">Manage student profiles and permissions.</p>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
          <input 
            type="text" 
            placeholder="Search students..." 
            className="pl-10 pr-4 py-2 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-full md:w-64 shadow-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredStudents.map((student) => (
          <div key={student.uid} className="bg-white rounded-2xl border border-neutral-200 shadow-sm overflow-hidden group hover:border-blue-200 transition-colors">
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold overflow-hidden">
                    {student.photoURL ? (
                      <img src={student.photoURL} alt={student.displayName} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                    ) : (
                      student.displayName.charAt(0)
                    )}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-neutral-900">{student.displayName}</h3>
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-600 uppercase tracking-wider">
                      Student
                    </span>
                  </div>
                </div>
                
                <div className="relative group/menu">
                  <button className="p-1 hover:bg-neutral-100 rounded-lg transition-colors">
                    <MoreVertical className="w-5 h-5 text-neutral-400" />
                  </button>
                  <div className="absolute right-0 top-full mt-1 w-48 bg-white border border-neutral-200 rounded-xl shadow-lg opacity-0 invisible group-hover/menu:opacity-100 group-hover/menu:visible transition-all z-10">
                    <div className="p-2 space-y-1">
                      <button 
                        onClick={() => handleRoleChange(student.uid, 'admin')}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-neutral-700 hover:bg-neutral-50 rounded-lg"
                      >
                        <Shield className="w-4 h-4 text-purple-500" />
                        Make Admin
                      </button>
                      <button 
                        onClick={() => handleRoleChange(student.uid, 'worker')}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-neutral-700 hover:bg-neutral-50 rounded-lg"
                      >
                        <HardHat className="w-4 h-4 text-orange-500" />
                        Make Worker
                      </button>
                      <div className="h-px bg-neutral-100 my-1" />
                      <button 
                        onClick={() => handleDelete(student.uid)}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-red-600 hover:bg-red-50 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                        Remove Student
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-3 text-xs text-neutral-600">
                  <Mail className="w-4 h-4 text-neutral-400" />
                  {student.email}
                </div>
                <div className="flex items-center gap-3 text-xs text-neutral-600">
                  <GraduationCap className="w-4 h-4 text-neutral-400" />
                  Computer Science (3rd Year)
                </div>
                <div className="flex items-center gap-3 text-xs text-neutral-600">
                  <Phone className="w-4 h-4 text-neutral-400" />
                  +1 (555) 000-0000
                </div>
              </div>
            </div>
            
            <div className="px-6 py-4 bg-neutral-50 border-t border-neutral-100 flex items-center justify-between">
              <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">Room: 302B</span>
              <button className="text-xs font-bold text-blue-600 hover:text-blue-700">View Profile</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
