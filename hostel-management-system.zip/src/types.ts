export type UserRole = 'admin' | 'student' | 'worker';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  photoURL?: string;
  createdAt: number;
}

export interface Room {
  id: string;
  roomNumber: string;
  capacity: number;
  occupants: string[]; // Array of student UIDs
  status: 'available' | 'full' | 'maintenance';
}

export interface Student {
  uid: string;
  name: string;
  email: string;
  roomNumber?: string;
  department?: string;
  phone?: string;
}

export interface Worker {
  id: string;
  name: string;
  role: string;
  phone: string;
  shift: 'morning' | 'afternoon' | 'night';
}

export interface FoodMenuItem {
  id: string;
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday';
  mealType: 'breakfast' | 'lunch' | 'dinner';
  items: string[];
  time: string;
}

export interface LibraryBook {
  id: string;
  title: string;
  author: string;
  category: string;
  status: 'available' | 'borrowed';
  borrowerId?: string;
  borrowerName?: string;
  dueDate?: string;
}

export interface Game {
  id: string;
  name: string;
  type: 'indoor' | 'outdoor';
  status: 'available' | 'in-use' | 'maintenance';
}

export interface Attendance {
  id: string;
  studentId: string;
  date: string; // YYYY-MM-DD
  status: 'present' | 'absent';
  timestamp: string;
}

export interface Feedback {
  id: string;
  studentId: string;
  studentName: string;
  message: string;
  rating: number;
  timestamp: string;
}
