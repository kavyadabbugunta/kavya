import React, { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { auth, api } from './firebase';
import { UserProfile } from './types';
import Layout from './components/Layout';
import { Bed, Loader2 } from 'lucide-react';

// Lazy load components
const Dashboard = React.lazy(() => import('./pages/Dashboard'));
const Students = React.lazy(() => import('./pages/Students'));
const Workers = React.lazy(() => import('./pages/Workers'));
const Rooms = React.lazy(() => import('./pages/Rooms'));
const FoodMenu = React.lazy(() => import('./pages/FoodMenu'));
const Library = React.lazy(() => import('./pages/Library'));
const Games = React.lazy(() => import('./pages/Games'));
const Attendance = React.lazy(() => import('./pages/Attendance'));
const Feedback = React.lazy(() => import('./pages/Feedback'));

export default function App() {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate auth check
    const checkAuth = async () => {
      try {
        const db = await api.getDb();
        const existingUser = db.users.find((u: any) => u.uid === auth.currentUser.uid);
        
        if (existingUser) {
          setUserProfile(existingUser);
        } else {
          // Auto-register mock admin
          const newUser = await api.create('users', auth.currentUser);
          setUserProfile(newUser);
        }
      } catch (error) {
        console.error("Auth error:", error);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-neutral-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Layout userProfile={userProfile}>
        <React.Suspense fallback={<Loader2 className="w-8 h-8 text-blue-600 animate-spin mx-auto mt-20" />}>
          <Routes>
            <Route path="/dashboard" element={<Dashboard userProfile={userProfile} />} />
            <Route path="/students" element={<Students userProfile={userProfile} />} />
            <Route path="/workers" element={<Workers userProfile={userProfile} />} />
            <Route path="/rooms" element={<Rooms userProfile={userProfile} />} />
            <Route path="/food-menu" element={<FoodMenu userProfile={userProfile} />} />
            <Route path="/library" element={<Library userProfile={userProfile} />} />
            <Route path="/games" element={<Games userProfile={userProfile} />} />
            <Route path="/attendance" element={<Attendance userProfile={userProfile} />} />
            <Route path="/feedback" element={<Feedback userProfile={userProfile} />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </React.Suspense>
      </Layout>
    </BrowserRouter>
  );
}
