import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs/promises";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_PATH = path.join(__dirname, 'db.json');

// Initial Data Structure
const INITIAL_DATA = {
  users: [],
  rooms: [
    { id: '1', roomNumber: '101', capacity: 2, occupants: [], status: 'available' },
    { id: '2', roomNumber: '102', capacity: 2, occupants: [], status: 'available' },
    { id: '3', roomNumber: '201', capacity: 4, occupants: [], status: 'available' },
  ],
  workers: [],
  foodMenu: [],
  library: [],
  games: [],
  attendance: [],
  feedback: []
};

async function getDb() {
  try {
    const data = await fs.readFile(DB_PATH, 'utf-8');
    return JSON.parse(data);
  } catch {
    await fs.writeFile(DB_PATH, JSON.stringify(INITIAL_DATA, null, 2));
    return INITIAL_DATA;
  }
}

async function saveDb(data: any) {
  await fs.writeFile(DB_PATH, JSON.stringify(data, null, 2));
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/db", async (req, res) => {
    const db = await getDb();
    res.json(db);
  });

  app.post("/api/:collection", async (req, res) => {
    const { collection } = req.params;
    const db = await getDb();
    if (!db[collection]) return res.status(404).json({ error: 'Collection not found' });
    
    const newItem = { id: Math.random().toString(36).substr(2, 9), ...req.body };
    db[collection].push(newItem);
    await saveDb(db);
    res.json(newItem);
  });

  app.put("/api/:collection/:id", async (req, res) => {
    const { collection, id } = req.params;
    const db = await getDb();
    if (!db[collection]) return res.status(404).json({ error: 'Collection not found' });
    
    const index = db[collection].findIndex((item: any) => item.id === id || item.uid === id);
    if (index === -1) return res.status(404).json({ error: 'Item not found' });
    
    db[collection][index] = { ...db[collection][index], ...req.body };
    await saveDb(db);
    res.json(db[collection][index]);
  });

  app.delete("/api/:collection/:id", async (req, res) => {
    const { collection, id } = req.params;
    const db = await getDb();
    if (!db[collection]) return res.status(404).json({ error: 'Collection not found' });
    
    db[collection] = db[collection].filter((item: any) => item.id !== id && item.uid !== id);
    await saveDb(db);
    res.status(204).send();
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
